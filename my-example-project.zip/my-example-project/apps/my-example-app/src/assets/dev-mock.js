window.document.addEventListener('DOMContentLoaded', () => {
  const services = {};
  const pageModel = {
    name: 'app-container',
    properties: {},
    children: [{
      name: 'example-widget',
      properties: {
        classId: 'ExampleWidgetComponent'
      }
    }],
  };

  window.BB.startSingleApp(services)
    .then(app => app.bootstrap(pageModel));
});