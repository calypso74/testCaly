export const environment = {
  production: true,
  mockProviders: [],
};
