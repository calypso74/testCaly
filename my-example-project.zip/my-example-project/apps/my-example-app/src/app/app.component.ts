import { Component } from '@angular/core';

@Component({
  selector: 'bb-my-example-app',
  template: '<bb-root></bb-root>'
})
export class AppComponent {}
