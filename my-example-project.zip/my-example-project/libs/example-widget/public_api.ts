export { ExampleWidgetModule } from './src/example-widget.module';
